package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Employee;
import com.spring.model.ModelClass;
import com.spring.service.ServiceClass;
@RestController
public class ControllerClass {
	@Autowired ServiceClass serviceclass;
	
	 

	@RequestMapping(value="/employee",method = RequestMethod.GET)
           
	public Employee greeting() {
		
		
		
		Employee emp=new Employee();
		emp.setEmpId(1);
		emp.setName("neha");
		emp.setDesignation("manager");
		return emp;
		
		
		
		
		
		
		
		
	}


	
	
	
}
