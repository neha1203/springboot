package com.spring.service;

import org.springframework.stereotype.Service;

import com.spring.model.ModelClass;


@Service
public class ServiceClass {
 
	public Boolean validate(ModelClass modelclass) {
		
		if((modelclass.getUsername().equals("neha")&&(modelclass.getPassword().equals("admin")))){
			
			  
		return true;	
			
		}

		else {
			
			return false;
			
		}
		// TODO Auto-generated method stub
	
	}

}
